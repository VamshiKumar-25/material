package com.example.maven_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MavenAppApplication.class, args);
	}

}
